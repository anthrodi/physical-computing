﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour {

	public Animator anim;

	// Use this for initialization
	void Start () {

		anim = GetComponent<Animator>();
	
	}
	
	// Update is called once per frame
	void Update () {

		Movement();
	
	}

	void Movement() {

		if(Input.GetKey (KeyCode.D))
		{
			transform.Translate(Vector2.right * 4f * Time.deltaTime);
			anim.SetBool("Right",true);
			anim.SetBool("Left",false);
		}

		if(Input.GetKey (KeyCode.A))
		{
			transform.Translate(-Vector2.right * 4f * Time.deltaTime);
			anim.SetBool("Left",true);
			anim.SetBool("Right",false);
		}
	}
}