﻿using UnityEngine;
using System.Collections;
using System.IO.Ports;

public class Arduino : MonoBehaviour {


	public float speed;
	private float amountToMove;
	public GameObject Player1;
	public GameObject Player2;
	public AudioClip Jump;

	SerialPort sp = new SerialPort("/dev/tty.usbmodemfa131", 9600);

	// Use this for initialization
	void Start () {

		sp.Open();
		sp.ReadTimeout = 1;

		Player1 = GameObject.FindWithTag("PlayerOne");
		Player2 = GameObject.FindWithTag("PlayerTwo");



	}
	
	// Update is called once per frame
	void Update () {

		amountToMove = speed * Time.deltaTime;

		if (sp.IsOpen) {

			try{
				MoveObject(sp.ReadByte());
				print(sp.ReadByte());
			}
			catch (System.Exception) {
			
			}

		}
	
	}

	void MoveObject(int Direction) {
	
		if (Player1 && Direction == 21) {

			transform.Translate (Vector3.up * amountToMove, Space.World);
			Player1.GetComponent<AudioSource>().Play();


		} 
		else {
		}

		if (Player2 && Direction == 22) {

			transform.Translate (Vector3.up * amountToMove, Space.World);
			Player2.GetComponent<AudioSource>().Play();

		
		} else {
		}

	
	}
}
