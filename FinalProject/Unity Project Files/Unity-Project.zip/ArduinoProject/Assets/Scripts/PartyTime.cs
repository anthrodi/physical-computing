﻿using UnityEngine;
using System.Collections;

public class PartyTime : MonoBehaviour {

	float elapsedTime;
	
	void Update()
	{
		elapsedTime += Time.deltaTime;
		
		if (elapsedTime >= 2) {
			elapsedTime -= 2;
			// insert logic for changing color below:
			GetComponent<Camera>().backgroundColor = Color.red;
		}
	}
}