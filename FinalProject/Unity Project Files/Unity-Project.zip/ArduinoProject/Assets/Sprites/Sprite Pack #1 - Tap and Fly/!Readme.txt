﻿Sprite Pack #1 - Tap and Fly

Example resource files contain sprites and sounds for helping you make simple 2D Tap and Fly games in Unity.

Features
- Three complete graphic themes.
- Sample Layouts and screenshots.
- Sample sounds.

Note
- All graphic files are 1x (SD scale).

Designed by Teera

Gold Experience Team
http://ge-team.com/pages/unity-3d/
http://ge-team.com/pages/sprite-pack/
geteamdev@gmail.com
